#include "LinkedList.h"
#include "Node.h"
using namespace std;

LinkedList::LinkedList() : head(nullptr), tail(nullptr), size(0) {}

LinkedList::~LinkedList() {
	Node* current = head;
	while (current != nullptr) {
		Node* next = current->next;
		delete current;
		current = next;
	}
}

LinkedList::LinkedList(const LinkedList& other) : head(nullptr), tail(nullptr), size(0) {
	Node* current = other.head;
	while (current != nullptr) {
		insert(current->data);
		current = current->next;
	}
}

LinkedList& LinkedList::operator=(const LinkedList& other) {
	if (this == &other) return *this;

	// Clear current list
	Node* current = head;
	while (current != nullptr) {
		Node* next = current->next;
		delete current;
		current = next;
	}

	// Copy from other
	head = nullptr;
	tail = nullptr;
	size = 0;
	current = other.head;
	while (current != nullptr) {
		insert(current->data);
		current = current->next;
	}

	return *this;
}

void LinkedList::insert(int value) {
	Node* newNode = new Node(value);
	if (head == nullptr) {
		head = tail = newNode;
	} else {
		tail->next = newNode;
		tail = newNode;
	}
	size++;
}

bool LinkedList::search(int value) const {
	Node* current = head;
	while (current != nullptr) {
		if (current->data == value) {
			return true;
		}
		current = current->next;
	}
	return false;
}

void LinkedList::print() const {
	Node* current = head;
	while (current != nullptr) {
		cout << current->data;
		current = current->next;
		if (current != nullptr) {
			cout << " ";
		}
	}
	cout << endl;
}


