<blockquote style="margin-bottom: 1.5em;">
  Name: Kai Gu<br>
  Course: CSCE 2110.003<br>
  TA: Yongshuo Liu<br>
  GitLab Repository Link: <a href="https://csegitlab.engineering.unt.edu/kg0909/linked-list-search">https://csegitlab.engineering.unt.edu/kg0909/linked-list-search</a>
</blockquote>


# Assignment 1: Searching with a Linked List

A C++ implementation of a singly linked list with insert, search, and print operations.

## Files

- `Node.h/cpp` - Node class with integer data and next pointer
- `LinkedList.h/cpp` - Linked list management with Rule of Five
- `main.cpp` - Interactive menu for user operations
- `test_linkedlist.cpp` - Unit tests using Google Test

## Build & Run

```bash
# Build
make

# Run interactive program
make run

# Run tests (requires gtest setup)
make test

# Clean build files
make clean
```

## Setup for Testing

The project uses Google Test for unit testing. If gtest is not available system-wide:

1.  Download gtest to `gtest/` directory
2.  Compile: `cd gtest/googletest-release-1.12.1 && g++ -std=c++17 -I./googletest/include -I./googletest -c googletest/src/gtest-all.cc -o gtest-all.o`
3.  Update Makefile to use local gtest (see comments in Makefile)

## Functionality

-  Insert integers at the end of the list
-  Search for integers in the list
-  Print all elements in the list
-  Interactive menu interface
-  Comprehensive unit tests
