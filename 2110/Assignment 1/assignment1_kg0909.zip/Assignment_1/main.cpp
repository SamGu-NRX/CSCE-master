#include <iostream>
#include "LinkedList.h"
using namespace std;

void printMenu() {
	cout << "\nMenu:\n";
	cout << "1) Insert integer\n";
	cout << "2) Search integer\n";
	cout << "3) Print list\n";
	cout << "4) Exit\n";
	cout << "Select option: ";
}

int main() {
	LinkedList list;
	int choice;

	while (true) {
		printMenu();
		cin >> choice;

		if (choice == 1) {
			cout << "Enter integer to insert: ";
			int value;
			cin >> value;
			list.insert(value);
			cout << "Inserted." << endl;
		}
		else if (choice == 2) {
			cout << "Enter integer to search: ";
			int value;
			cin >> value;
			if (list.search(value)) {
				cout << "Found" << endl;
			} else {
				cout << "Not found" << endl;
			}
		}
		else if (choice == 3) {
			if (list.empty()) {
				cout << "List is empty" << endl;
			} else {
				cout << "List: ";
				list.print();
			}
		}
		else if (choice == 4) {
			break;
		}
		else {
			cout << "Invalid option. Try again." << endl;
		}
	}

	cout << "Goodbye!" << endl;
	return 0;
}
