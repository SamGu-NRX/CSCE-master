#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
#include "Node.h"
using namespace std;

class LinkedList {
private:
	Node* head;
	Node* tail;
	int size;

public:
	LinkedList();
	~LinkedList();
	LinkedList(const LinkedList& other);
	LinkedList& operator=(const LinkedList& other);

	void insert(int value);
	bool search(int value) const;
	void print() const;
	int getSize() const { return size; }
	bool empty() const { return size == 0; }
};

#endif // LINKEDLIST_H


