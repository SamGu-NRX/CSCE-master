// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#ifndef BOOKS_H
#define BOOKS_H

#include <vector>
#include "Book.h"

using namespace std;

class Books {
private:
    vector<Book> BookList;

public:
    void addBook(const Book& bookRef);
    void editBook(const Book& bookRef, char choice, const string& changedParam);
    void editBook(const Book& bookRef, char choice, int changedParam);
    void editBook(const Book& bookRef, char choice, double changedParam);
    void editBook(Book& bookRef, char choice, BookStatus changedParam);
    Book& getBook(int index);
    void deleteBook(int id);
    int findBook(int id) const;
    const Book& findBook(const string& name) const;
    void printBooks() const;
    void printAllDetails(int id) const;
};

#endif
