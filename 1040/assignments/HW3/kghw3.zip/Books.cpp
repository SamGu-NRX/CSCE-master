// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#include "Books.h"
#include <iostream>
#include <algorithm>

using namespace std;
// Some functionalities implemented in main.cpp


// Prompt user for Author Prompt user for Title
// Prompt user for ISBN_Number
// Prompt user for Library ID
// Prompt user for Cost
// Create and populate Book Object via parameterized constructor
// Add object to Books collection
void Books::addBook(const Book& bookRef) {
    BookList.push_back(bookRef);
}

// Prompt the user for Book ID
// Use findBook to get the index of the Book with the user-specified ID
// For the first parameter of editBook(), insert the memory reference of the Book object using the index of the Book.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findBook() does not return -1 (i.e. book is in the bookList vector).
// If findBook() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Book object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Books::editBook(const Book& bookRef, char choice, const string& changedParam) {
    int index = findBook(bookRef.getID());
    if (index != -1) {
        switch (choice) {
            case 'a':
                BookList[index].setAuthor(changedParam);
                break;
            case 't':
                BookList[index].setTitle(changedParam);
                break;
            default:
                cout << "Invalid choice." << endl;
        }
    }
}

// Prompt the user for Book ID
// Use findBook to get the index of the Book with the user-specified ID
// For the first parameter of editBook(), insert the memory reference of the Book object using the index of the Book.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findBook() does not return -1 (i.e. book is in the bookList vector).
// If findBook() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Book object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Books::editBook(const Book& bookRef, char choice, int changedParam) {
    int index = findBook(bookRef.getID());
    if (index != -1) {
        switch (choice) {
            case 'i':
                BookList[index].setISBN(changedParam);
                break;
            case 'd':
                BookList[index].setID(changedParam);
                break;
            default:
                cout << "Invalid choice." << endl;
        }
    }
}

// Prompt the user for Book ID
// Use findBook to get the index of the Book with the user-specified ID
// For the first parameter of editBook(), insert the memory reference of the Book object using the index of the Book.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findBook() does not return -1 (i.e. book is in the bookList vector).
// If findBook() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Book object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Books::editBook(const Book& bookRef, char choice, double changedParam) {
    int index = findBook(bookRef.getID());
    if (index != -1) {
        if (choice == 'c') {
            BookList[index].setCost(changedParam);
        } else {
            cout << "Invalid choice." << endl;
        }
    }
}

// Prompt the user for Book ID
// Use findBook to get the index of the Book with the user-specified ID
// For the first parameter of editBook(), insert the memory reference of the Book object using the index of the Book.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findBook() does not return -1 (i.e. book is in the bookList vector).
// If findBook() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Book object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Books::editBook(Book& bookRef, char choice, BookStatus changedParam) {
    if (tolower(choice) == 's') {
        bookRef.setStatus(changedParam);
    } else {
        cout << "Invalid choice." << endl;
    }
}

// Check if the provided index is valid (not equal to -1).
// If valid: Return the book located at BookList[index].
// Else: Throw a runtime error with the message "Book not found."
Book& Books::getBook(int index) {
    if (index != -1) {
        return BookList[index];
    } else {
        __throw_runtime_error("Book not found.");
    }
}

// Prompt user for a Book ID
// Use Method findBook() to get the index of the Book with the user-specified ID
// If the index received from findBook() is not -1, make the Books Collection delete the index.
void Books::deleteBook(int id) {
    int index = findBook(id);
    if (index != -1) {
        BookList.erase(BookList.begin() + index);
        cout << "Book deleted successfully." << endl;
    } else {
        cout << "Book not found." << endl;
    }
}

// Prompt user for ID
// Iterate through Book collection using for-loop
// Check for ID that matches the user’s given ID
// Return index of Book in the bookList vector with the the matching ID
int Books::findBook(int id) const {
    for (size_t i = 0; i < BookList.size(); ++i) {
        if (BookList[i].getID() == id) {
            return i;
        }
    }
    return -1;
}

// Prompt user for Name
// Iterate through Book collection using for-loop
// Check for Name that matches the user’s given Name
// Return index of the Book with the matching Name
const Book& Books::findBook(const string& name) const {
    for (const Book& book : BookList) {
        if (book.getTitle() == name) {
            return book;
        }
    }
    __throw_runtime_error("Book not found.");
}

// Iterate through the vector using a for-loop and print out all elements of the Books collection
void Books::printBooks() const {
    for (const auto& book : BookList) {
        cout << "ID: " << book.getID()
                  << ", Title: " << book.getTitle()
                  << ", Author: " << book.getAuthor()
                  << ", Status: " << book.getStatus() << endl;
    }
}

// Prompt the user for a Book ID
// Use findBook() to get the index of the Book in the vector with the user’s given ID
// If findBook() does not return -1 (or that the Book does exist), Print out the Name, ID, Author, Title, ISBN_Number, and Cost of the element at the index returned by findBook(). (using accessors for each attribute)
void Books::printAllDetails(int id) const {
    int index = findBook(id);
    if (index != -1) {
        const Book& book = BookList[index];
        cout << "ID: " << book.getID() << endl;
        cout << "Title: " << book.getTitle() << endl;
        cout << "Author: " << book.getAuthor() << endl;
        cout << "ISBN: " << book.getISBN() << endl;
        cout << "Cost: " << book.getCost() << endl;
        cout << "Status: " << book.getStatus() << endl;
    } else {
        cout << "Book not found." << endl;
    }
}

