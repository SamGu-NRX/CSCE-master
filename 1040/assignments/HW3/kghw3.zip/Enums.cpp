#include "Enums.h"

string loanStatusToString(LoanStatus status) {
    return loanStatusStrings[status];
}

string bookStatusToString(BookStatus status) {
    return bookStatusStrings[status];
}
