// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#ifndef PATRON_H
#define PATRON_H

#include <string>

using namespace std;

class Patron {
private:
    string name;
    int id;
    int numberOfBooksOut;
    double fineBalance;
    bool canCheckOut;

public:
    Patron(string name, int id, int currentBookOutCount);

    // Getters
    int getID() const;
    string getName() const;
    double getFineBalance() const;
    int getNumBooksOut() const;
    bool getCanCheckOut() const;

    // Setters
    void setID(int id);
    void setName(const string& name);
    void setCanCheckOut(bool status);
    void setFineBalance(double bal);
    void addFine(double amount);

};

#endif
