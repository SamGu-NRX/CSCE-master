// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#include "Book.h"
#include "Enums.h"

using namespace std;

Book::Book(string author, string title, int ISBN, int ID, double cost, BookStatus status)
    : author(author), title(title), isbnNumber(ISBN), id(ID), cost(cost), status(status) {}

// Getters
string Book::getAuthor() const { return author; }
string Book::getTitle() const { return title; }
int Book::getISBN() const { return isbnNumber; }
int Book::getID() const { return id; }
double Book::getCost() const { return cost; }
string Book::getStatus() const { return bookStatusToString(status); }

// Setters
void Book::setAuthor(const string& author) { this->author = author; }
void Book::setTitle(const string& title) { this->title = title; }
void Book::setISBN(int isbn) { isbnNumber = isbn; }
void Book::setID(int id) { this->id = id; }
void Book::setCost(double cost) { this->cost = cost; }
void Book::setStatus(BookStatus status) { this->status = status; }

// Other Functions
void Book::changeStatus(BookStatus status) { this->status = status; }
