#ifndef LOAN_H
#define LOAN_H

#include <ctime>
#include <string>
#include "Enums.h"

using namespace std;

class Loan {
private:
    int id;
    int patronID;
    int bookID;
    time_t dueDateAndTime;
    bool canRecheck;
    LoanStatus status;
    double fineRate;

public:
    Loan(int loanID, int patronID, int bookID);

    // Getters
    int getID() const;
    int getPatronID() const;
    int getBookID() const;
    bool getCanRecheck() const;
    string getStatus() const;
    time_t getDueDateAndTime() const;
    string printDueDateAndTime() const;
    double getFineRate() const;

    // Setters
    void setID(int id);
    void setStatus(LoanStatus status);
    void setDueDateAndTime(time_t dueDate);
    void setCanRecheck(bool canRecheck);
    void setFineRate(int rate);
};

#endif
