// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#ifndef LOANS_H
#define LOANS_H

#include <vector>
#include "Loan.h"
#include "Books.h"
#include "Patrons.h"

using namespace std;

class Loans {
private:
    vector<Loan> LoanList;
    vector<Loan> overdueLoans;

public:
    void addLoan(const Loan& loanRef);
    void editLoan(const Loan& loanRef, char choice, int changedParam);
    void editLoan(const Loan& loanRef, char choice, bool changedParam);
    void deleteLoan(int id);
    int findLoan(int id) const;
    Loan& getLoan(int index);
    void printLoans() const;
    void listAllOverdueLoans();
    void aggregateOverdueLoans();
    void calculateLoans(int id);
    void updateLoanStatus(int id);
    void reportLost(const Loan& loanRef, Books& books, Patrons& patrons);
    int generateLoanID() const;
};

#endif
