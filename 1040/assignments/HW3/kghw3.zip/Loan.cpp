// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#include "Loan.h"
#include "Enums.h"
#include <ctime>

using namespace std;

Loan::Loan(int loanID, int patronID, int bookID)
    : id(loanID), patronID(patronID), bookID(bookID), canRecheck(true),
      status(LoanStatus::NORMAL), fineRate(0.25) {
   // Set due date to 10 days from now
   dueDateAndTime = time(0) + 10 * 24 * 60 * 60;
}

// Getters
int Loan::getID() const { return id; }

int Loan::getPatronID() const { return patronID; }
int Loan::getBookID() const { return bookID; }
bool Loan::getCanRecheck() const { return canRecheck; }
string Loan::getStatus() const { return loanStatusToString(status); }
time_t Loan::getDueDateAndTime() const { return dueDateAndTime; }
double Loan::getFineRate() const { return fineRate; }

// helper
string Loan::printDueDateAndTime() const {
    // Convert time_t to a string representation in YY-MM-DD HH:MM:SS
    char buffer[20];
    struct tm* dueDate = localtime(&dueDateAndTime);
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", dueDate);
    return string(buffer);
}


// Setters
void Loan::setID(int id) { this->id = id; }
void Loan::setStatus(LoanStatus status) { this->status = status; }
void Loan::setDueDateAndTime(time_t dueDate) { dueDateAndTime = dueDate; }
void Loan::setCanRecheck(bool canRecheck) { this->canRecheck = canRecheck; }
void Loan::setFineRate(int rate) { fineRate = rate; }
