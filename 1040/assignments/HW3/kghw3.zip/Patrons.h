// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#ifndef PATRONS_H
#define PATRONS_H

#include <vector>
#include "Patron.h"

using namespace std;

class Patrons {
private:
    vector<Patron> PatronList;

public:
    void addPatron(const Patron& patronRef);
    void editPatron(const Patron& patronRef, char choice, const string& changedParam);
    void editPatron(const Patron& patronRef, char choice, int changedParam);
    void editPatron(const Patron& patronRef, char choice, double changedParam);
    void deletePatron(int id);
    int findPatron(int id) const;
    Patron findPatron(const string& name) const;
    Patron& getPatron(int index);
    void printPatrons() const;
    void printAllDetails(int id) const;
    void payFines(const Patron& patronRef, double finePaid);
    double printPatronFine(const Patron& patronRef);
};

#endif
