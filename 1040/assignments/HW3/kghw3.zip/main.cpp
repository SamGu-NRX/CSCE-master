// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#include <iostream>
#include "Books.h"
#include "Patrons.h"
#include "Loans.h"
#include <cmath>

using namespace std;

void printMenu() {
    cout << "\nLibrary Management System\n";
    cout << "1. List Books\n";
    cout << "2. List Patrons\n";
    cout << "3. List Loans\n";
    cout << "4. List All Overdue Loans\n";

    cout << "5. Add Book\n";
    cout << "6. Add Patron\n";
    cout << "7. Checkout/Recheck Book\n";

    cout << "8. Delete Book\n";
    cout << "9. Delete Patron\n";
    cout << "10. Return Book\n";

    cout << "11. Edit Book\n";
    cout << "12. Edit Patron\n";
    cout << "13. Edit Loan\n";

    cout << "14. Pay Patron Fine\n";
    cout << "15. Report Book Lost\n";

    cout << "16. Print Book Details\n";
    cout << "17. Print Patron Details\n";

    cout << "q - Exit\n\n";
    cout << "Enter choice: ";
}

void executeChoice(int choice, Books& books, Patrons& patrons, Loans& loans) {
    switch (choice) {

        // List all books
        case 1:
            books.printBooks();
            break;

        // List all patrons
        case 2:
            patrons.printPatrons();
            break;

        // List all loans
        case 3:
            loans.printLoans();
            break;

        // List all overdue loans
        case 4: {
            loans.listAllOverdueLoans();
            break;
        }

        // Add book
        case 5: {
            string title, author;
            int isbn, id;
            double cost;
            int statusInt;
            BookStatus status;

            cout << "Enter book details:" << endl;
            cout << "Author: ";
            cin.ignore();
            getline(cin, author);
            cout << "Title: ";
            getline(cin, title);
            cout << "ISBN: ";
            cin >> isbn;
            cout << "ID: ";
            cin >> id;
            cout << "Cost: ";
            cin >> cost;
            cout << "Status (0=IN, 1=OUT, 2=REPAIR, 3=LOST): ";
            cin >> statusInt;
            status = static_cast<BookStatus>(statusInt);

            Book newBook = Book(author, title, isbn, id, cost, status);
            books.addBook(newBook);

            break;
        }

        // Add patron
        case 6: {
            string name;
            int id;
            int numBooksOut;
            cout << "Enter patron details:" << endl;
            cout << "Name: ";
            cin.ignore();
            getline(cin, name);
            cout << "ID: ";
            cin >> id;
            cout << "Number of books out: ";
            cin >> numBooksOut;

            Patron newPatron = Patron(name, id, numBooksOut);


            patrons.addPatron(newPatron);
            break;
        }

 // Checkout/Recheck book
        case 7: {
            int subChoice;
            cout << "\nChoose an option:\n";
            cout << "1. Check-Out Book\n";
            cout << "2. Recheck Book\n";
            cout << "Enter your choice: ";
            cin >> subChoice;

            // Check-Out Book
            if (subChoice == 1) {
                int patronID, bookID;
                cout << "Enter Patron ID: ";
                cin >> patronID;

                // Validate Patron
                int patronIndex = patrons.findPatron(patronID);
                if (patronIndex == -1) {
                    cout << "Patron with ID " << patronID << " not found." << endl;
                    break;
                }

                Patron& patron = patrons.getPatron(patronIndex);
                if (patron.getNumBooksOut() >= 6) {
                    cout << "Patron has already checked out 6 books. Cannot check out more." << endl;
                    break;
                }

                cout << "Enter Book ID to check out: ";
                cin >> bookID;

                // Validate Book
                int bookIndex = books.findBook(bookID);
                if (bookIndex == -1) {
                    cout << "Book with ID " << bookID << " not found." << endl;
                    break;
                }

                Book& book = books.getBook(bookIndex);
                if (book.getStatus() != "IN") {
                    cout << "Book is " << book.getStatus() << ", and not available for check-out." << endl;
                    break;
                }

                // Generate a unique Loan ID
                int loanID = loans.generateLoanID();

                // Create Loan object
                Loan newLoan(loanID, patronID, bookID);

                // Add the loan
                loans.addLoan(newLoan);

                // Update Book status to CHECKED_OUT
                book.setStatus(BookStatus::OUT);

                cout << "Book with ID " << bookID << " has been checked out to Patron ID " << patronID << "." << endl;
                cout << "Loan ID: " << loanID << ", Due Date: " << newLoan.printDueDateAndTime() << endl;

            }
            // Recheck Book
            else if (subChoice == 2) {
                int loanID;
                cout << "Enter Loan ID to recheck: ";
                cin >> loanID;

                // Validate Loan
                int loanIndex = loans.findLoan(loanID);
                if (loanIndex == -1) {
                    cout << "Loan with ID " << loanID << " not found." << endl;
                    break;
                }

                Loan& loan = loans.getLoan(loanIndex);

                // Check if loan is eligible for recheck
                if (!loan.getCanRecheck()) {
                    cout << "This loan has already been rechecked once. Recheck not allowed." << endl;
                    break;
                }

                // Extend due date by 10 days
                time_t currentDueDate = loan.getDueDateAndTime();
                time_t newDueDate = currentDueDate + 10 * 24 * 60 * 60; // Additional 10 days

                loan.setDueDateAndTime(newDueDate);
                loan.setCanRecheck(false); // Recheck used

                cout << "Loan ID " << loanID << " has been rechecked. New Due Date: " << loan.printDueDateAndTime() << endl;

            } else {
                cout << "Invalid sub-choice. Please enter 1 or 2." << endl;
            }

            break;
        }

        // Delete book
        case 8: {
            int id;
            cout << "Enter book ID to delete: ";
            cin >> id;
            books.deleteBook(id);
            break;
        }

        // Delete patron
        case 9: {
            int id;
            cout << "Enter patron ID to delete: ";
            cin >> id;
            patrons.deletePatron(id);
            break;
        }

        // Return Book
        case 10: {
            int loanID;
            cout << "Enter Loan ID to return the book: ";
            cin >> loanID;

            // Validate Loan
            int loanIndex = loans.findLoan(loanID);
            if (loanIndex == -1) {
                cout << "Loan with ID " << loanID << " not found." << endl;
                break;
            }

            try {
                Loan& loan = loans.getLoan(loanIndex);

                // Get current time and due date
                time_t now = time(0);
                time_t dueDate = loan.getDueDateAndTime();

                // Calculate if the loan is overdue
                double secondsOverdue = difftime(now, dueDate);
                double daysOverdue = secondsOverdue / (60 * 60 * 24);

                double fine = 0.0;
                if (secondsOverdue > 0) {
                    // Round up to the next whole day
                    fine = ceil(daysOverdue) * loan.getFineRate();

                    // Find the patron and add the fine
                    int patronID = loan.getPatronID();
                    int patronIndex = patrons.findPatron(patronID);
                    if (patronIndex != -1) {
                        Patron& patron = patrons.getPatron(patronIndex);
                        patron.addFine(fine);
                        cout << "Book is overdue by " << static_cast<int>(daysOverdue)
                                << " days. Fine of $" << fine << " has been added to Patron ID "
                                << patronID << "." << endl;
                    } else {
                        cout << "Patron with ID " << patronID << " not found. Cannot add fine." << endl;
                    }
                } else {
                    cout << "Book is returned on time. No fines incurred." << endl;
                }

                int bookID = loan.getBookID();
                int bookIndex = books.findBook(bookID);
                if (bookIndex != -1) {
                    Book& book = books.getBook(bookIndex);
                    book.setStatus(BookStatus::IN);
                    cout << "Book with ID " << bookID << " has been returned and is now available." << endl;
                } else {
                    cout << "Book with ID " << bookID << " not found. Cannot update status." << endl;
                }

                // Delete the loan from the Loans list
                loans.deleteLoan(loanID);
                cout << "Loan with ID " << loanID << " has been successfully returned and deleted." << endl;

            } catch (const exception& e) {
                cout << "Error processing return: " << e.what() << endl;
            }

            break;
        }

        // Edit book
        case 11: {
            int id;
            char choice;
            cout << "Enter book ID to edit: ";
            cin >> id;

            int bookIndex = books.findBook(id);
            while (bookIndex == -1) {
                cout << "Invalid book ID. Please try again." << endl;
                cout << "Enter book ID to edit: ";
                cin >> id;
                bookIndex = books.findBook(id);
            }

            Book& book = books.getBook(bookIndex);

            cout << "What would you like to edit? (a)uthor, (t)itle, (i)sbn, (c)ost, (s)tatus: ";
            cin >> choice;

            switch (tolower(choice)) {
                case 'a': {
                    string author;
                    cout << "Enter new author: ";
                    cin.ignore();
                    getline(cin, author);
                    books.editBook(book, choice, author);
                    break;
                }

                case 't' : {
                    string title;
                    cout << "Enter new title: ";
                    cin.ignore();
                    getline(cin, title);
                    books.editBook(book, choice, title);
                    break;
                }

                case 'i': {
                    int ISBN;
                    cout << "Enter new ISBN: ";
                    cin >> ISBN;
                    books.editBook(book, choice, ISBN);
                    break;
                }

                case 'c': {
                    double cost;
                    cout << "Enter new cost: ";
                    cin >> cost;
                    books.editBook(book, choice, cost);
                    break;
                }

                case 's': {
                    int statusInt;
                    cout << "Enter new status (0=IN, 1=OUT, 2=REPAIR, 3=LOST): ";
                    cin >> statusInt;
                    BookStatus status = static_cast<BookStatus>(statusInt);
                    books.editBook(book, choice, status);
                    break;
                }

                default:
                    cout << "Invalid choice. Please try again." << endl;
                    break;
            }
            break;
        }

        // Edit patron
        case 12: {
            int id;
            char choice;

            cout << "Enter patron ID to edit: ";
            cin >> id;

            int patronIndex = patrons.findPatron(id);
            while (patronIndex == -1) {
                cout << "Invalid patron ID. Please try again." << endl;
                cout << "Enter patron ID to edit: ";
                cin >> id;
                patronIndex = patrons.findPatron(id);
            }

            Patron& patron = patrons.getPatron(patronIndex);

            cout << "What would you like to edit? (n)ame, (c)an check out, (i)d: ";
            cin >> choice;

            switch (tolower(choice)) {
                case 'n': {
                    string name;
                    cout << "Enter new name: ";
                    cin.ignore();
                    getline(cin, name);
                    patrons.editPatron(patron, choice, name);
                    break;
                }

                case 'c': {
                    bool canCheckOut;
                    cout << "Enter new check out status (0=No, 1=Yes): ";
                    cin >> canCheckOut;
                    patrons.editPatron(patron, choice, canCheckOut);
                    break;
                }

                case 'i': {
                    int id;
                    cout << "Enter new ID: ";
                    cin >> id;
                    patrons.editPatron(patron, choice, id);
                    break;
                }

                default:
                    cout << "Invalid choice. Please try again." << endl;
                    break;
            }
            break;
        }

        // Edit loan
        case 13: {
            int id;
            char choice;

            cout << "Enter loan ID to edit: ";
            cin >> id;

            int loanIndex = loans.findLoan(id);
            while (loanIndex == -1) {
                cout << "Invalid loan ID. Please try again." << endl;
                cout << "Enter loan ID to edit: ";
                cin >> id;
                loanIndex = loans.findLoan(id);
            }

            Loan& loan = loans.getLoan(loanIndex);

            cout << "What would you like to edit? (d)ue date, (s)tatus: ";
            cin >> choice;

            switch (tolower(choice)) {
                case 'd': {
                    time_t dueDate;
                    cout << "Enter new due date (as UNIX timestamp): ";
                    cin >> dueDate;
                    loan.setDueDateAndTime(dueDate);
                    break;
                }

                case 's': {
                    int statusInt;
                    cout << "Enter new status (0=NORMAL, 1=OVERDUE): ";
                    cin >> statusInt;
                    LoanStatus status = static_cast<LoanStatus>(statusInt);
                    loan.setStatus(status);
                    break;
                }

                default:
                    cout << "Invalid choice. Please try again." << endl;
                    break;
            }
            break;
        }

        // Pay fine (for a patron)
        case 14: {
            int id;
            double amount;
            cout << "Enter patron ID to pay fine: ";
            cin >> id;

            int patronIndex = patrons.findPatron(id);
            while (patronIndex == -1) {
                cout << "Invalid patron ID. Please try again." << endl;
                cout << "Enter patron ID to pay fine: ";
                cin >> id;
                patronIndex = patrons.findPatron(id);
            }

            Patron& patron = patrons.getPatron(patronIndex);


            int fines = patrons.printPatronFine(patron);
            if (fines == 0) {
                cout << "No fines to pay." << endl;
                break;
            }

            cout << "Enter amount to pay: ";
            cin >> amount;

            patrons.payFines(patron, amount);
            break;
        }

        // Report book lost
        case 15: {
            int id;
            cout << "Enter loan ID to report as lost: ";
            cin >> id;

            int index = loans.findLoan(id);
            Loan& loan = loans.getLoan(index);
            loans.reportLost(loan, books, patrons);
            break;
        }

        // Check all details of book
        case 16: {
            int id;
            cout << "Enter book ID to check details: ";
            cin >> id;
            books.printAllDetails(id);
            break;
        }

        // Check all details of patron
        case 17: {
            int id;
            cout << "Enter patron ID to check details: ";
            cin >> id;
            patrons.printAllDetails(id);
            break;
        }

        default:
            cout << "Invalid choice. Please try again." << endl;
            break;

    }
}

int main() {
    Books books;
    Patrons patrons;
    Loans loans;

    cout << "Library Management System" << endl;
    cout << "This contains 2 sample books, 2 sample patrons, and 1 sample loan." << endl;

    // Sample data
    Book book1("Author A", "Title A", 123456, 1, 29.99, BookStatus::OUT);
    Book book2("Author B", "Title B", 654321, 2, 39.99, BookStatus::IN);
    books.addBook(book1);
    books.addBook(book2);

    Patron patron1("John Doe", 1, 1);
    Patron patron2("Jane Smith", 2, 0);
    patrons.addPatron(patron1);
    patrons.addPatron(patron2);

    Loan loan1(1, patron1.getID(), book1.getID());
    loans.addLoan(loan1);

    // Main menu loop
    string choice;
    do {
        printMenu();
        cin >> choice;

        if (choice == "q" || choice == "Q") {
            cout << "Exiting..." << endl;
            break;
        } else {
            try {
                // Reference: https://stackoverflow.com/questions/7663709/how-can-i-convert-a-stdstring-to-int
                int intChoice = stoi(choice);
                executeChoice(intChoice, books, patrons, loans);
            } catch (std::invalid_argument& e) {
                cout << "Invalid input. Please enter a number between 1 to 17 or 'q' to quit." << endl;
            }
        }
    } while (true);

    return 0;
}
