// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#include "Patron.h"

using namespace std;

Patron::Patron(string name, int id, int currentBookOutCount)
    : name(name), id(id), numberOfBooksOut(currentBookOutCount), fineBalance(0.0), canCheckOut(true) {}

// Getters
int Patron::getID() const { return id; }
string Patron::getName() const { return name; }
double Patron::getFineBalance() const { return fineBalance; }
int Patron::getNumBooksOut() const { return numberOfBooksOut; }
bool Patron::getCanCheckOut() const { return canCheckOut; }

// Setters
void Patron::setID(int id) { this->id = id; }
void Patron::setName(const string& name) { this->name = name; }
void Patron::setCanCheckOut(bool status) { canCheckOut = status; }
void Patron::setFineBalance(double bal) { fineBalance = bal; }
void Patron::addFine(double amount) { fineBalance += amount; }
