// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#ifndef BOOK_H
#define BOOK_H

#include <string>
#include "Enums.h"

using namespace std;

class Book {
private:
    string author;
    string title;
    int isbnNumber;
    int id;
    double cost;
    BookStatus status;

public:
    Book(string author, string title, int ISBN, int ID, double cost, BookStatus status);

    // Getters
    string getAuthor() const;
    string getTitle() const;
    int getISBN() const;
    int getID() const;
    double getCost() const;
    string getStatus() const;

    // Setters
    void setAuthor(const string& author);
    void setTitle(const string& title);
    void setISBN(int isbn);
    void setID(int id);
    void setCost(double cost);
    void setStatus(BookStatus status);

    // Other Functions
    void changeStatus(BookStatus status);
};

#endif
