// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#include "Patrons.h"
#include <iostream>

using namespace std;
// Some functionalities implemented in main.cpp



// Prompt user for Name
// Prompt user for ID
// Prompt user for Current Number of Books Out
// Create and populate Patron object via parameterized constructor
// Add object to Patrons collection
void Patrons::addPatron(const Patron& patronRef) {
    PatronList.push_back(patronRef);
}

// Prompt the user for Patron ID
// Use findPatron to get the index of the Patron with the user-specified ID
// For the param of editPatron(), insert the memory reference of the Patron object using the index of the Patron.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findPatron() does not return -1 (i.e. Patron is in the Patron collection).
// If findPatron() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Patron object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Patrons::editPatron(const Patron& patronRef, char choice, const string& changedParam) {
    int index = findPatron(patronRef.getID());
    if (index != -1) {
        if (choice == 'n') {
            PatronList[index].setName(changedParam);
        } else {
            cout << "Invalid choice." << endl;
        }
    }
}

// Prompt the user for Patron ID
// Use findPatron to get the index of the Patron with the user-specified ID
// For the param of editPatron(), insert the memory reference of the Patron object using the index of the Patron.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findPatron() does not return -1 (i.e. Patron is in the Patron collection).
// If findPatron() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Patron object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Patrons::editPatron(const Patron& patronRef, char choice, int changedParam) {
    int index = findPatron(patronRef.getID());
    if (index != -1) {
        if (choice == 'i') {
            PatronList[index].setID(changedParam);
        }
        else if (choice == 'c') {
            PatronList[index].setCanCheckOut(changedParam);
        }
        else {
            cout << "Invalid choice." << endl;
        }
    }
}

// Prompt the user for Patron ID
// Use findPatron to get the index of the Patron with the user-specified ID
// For the param of editPatron(), insert the memory reference of the Patron object using the index of the Patron.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findPatron() does not return -1 (i.e. Patron is in the Patron collection).
// If findPatron() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Patron object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Patrons::editPatron(const Patron& patronRef, char choice, double changedParam) {
    int index = findPatron(patronRef.getID());
    if (index != -1) {
        if (choice == 'f') {
            PatronList[index].setFineBalance(changedParam);
        } else {
            cout << "Invalid choice." << endl;
        }
    }
}

// Prompt user for a Patron ID
// Use Method findPatron() to get the index of the Patron with the user-specified ID
// If the index received from findPatron() is not -1, make the Patron collection delete the index.
void Patrons::deletePatron(int id) {
    int index = findPatron(id);
    if (index != -1) {
        PatronList.erase(PatronList.begin() + index);
        cout << "Patron deleted successfully." << endl;
    } else {
        cout << "Patron not found." << endl;
    }
}

// Prompt user for ID
// Linear search through Patron collection
// Check for ID that matches the user’s given ID
// Return index of Patron in the Patron collection with the matching ID
int Patrons::findPatron(int id) const {
    for (size_t i = 0; i < PatronList.size(); ++i) {
        if (PatronList[i].getID() == id) {
            return i;
        }
    }
    return -1;
}

// Prompt user for Name
// Search through Patron collection
// Check for Name that matches the user’s given Name
// Return index of the Patron with the matching Name
Patron Patrons::findPatron(const string& name) const {
    for (const auto& patron : PatronList) {
        if (patron.getName() == name) {
            return patron;
        }
    }
    return Patron("", 0, 0);
}

// Check if the provided index is valid (not equal to -1).
// If valid: Return the patron located at PatronList[index].
// Else: Throw a runtime error with the message "Patron not found."
Patron& Patrons::getPatron(int index) {
    if (index != -1) {
        return PatronList[index];
    } else {
        throw runtime_error("Patron not found.");
    }
}

// Iterate through the patronList vector using a for-loop and print out all elements of the Patrons collection
void Patrons::printPatrons() const {
    for (const auto& patron : PatronList) {
        cout << "ID: " << patron.getID()
                  << ", Name: " << patron.getName()
                  << ", Books Out: " << patron.getNumBooksOut() << endl;
    }
}

// Prompt the user for a Patron ID
// Use findPatron() to get the index of the Patron in the vector with the user’s given ID
// If findPatron() does not return -1 (or the Patron does exist), Print out the Name, ID, and Current Number of Books Checked Out of the element at the index returned by findPatron().
void Patrons::printAllDetails(int id) const {
    int index = findPatron(id);
    if (index != -1) {
        const Patron& patron = PatronList[index];
        cout << "ID: " << patron.getID() << endl;
        cout << "Name: " << patron.getName() << endl;
        cout << "Books Out: " << patron.getNumBooksOut() << endl;
        cout << "Fine Balance: $" << patron.getFineBalance() << endl;
        cout << "Can Check Out: " << (patron.getCanCheckOut() ? "Yes" : "No") << endl;
    } else {
        cout << "Patron not found." << endl;
    }
}

// Prompt the user for Patron ID
// Use findPatron() to get the index of the Patron with the user-specified ID
// For the first parameter of editLoan(), insert the memory reference of the Patron object using the returned patron index.
// If the second parameter (finePaid) is greater than 0 and less than or equal to the double returned by getFineBalance() for the Patron object reference, subtract the amount paid from the existing amount using the mutator setFineBalance()
void Patrons::payFines(const Patron& patronRef, double finePaid) {
    int index = findPatron(patronRef.getID());
    if (index != -1) {
        double newBalance = PatronList[index].getFineBalance() - finePaid;
        PatronList[index].setFineBalance(newBalance > 0 ? newBalance : 0);
        cout << "Fine paid successfully. New balance: $" << PatronList[index].getFineBalance() << endl;
        if(newBalance < 0) {
            cout << "You have been returned your $" << -newBalance << " change." << endl;
        }
    } else {
        cout << "Patron not found." << endl;
    }
}

// Display the patron's name followed by their current fine balance in the format: "[Patron Name]'s fine balance: $[Fine Amount]".
// Return the patron's fine balance.
double Patrons::printPatronFine(const Patron& patronRef) {
    cout << patronRef.getName() << "'s fine balance: $" << patronRef.getFineBalance() << endl;
    return patronRef.getFineBalance();
}
