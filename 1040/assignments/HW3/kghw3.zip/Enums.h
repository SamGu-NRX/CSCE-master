#ifndef ENUMS_H
#define ENUMS_H

#include <array>
#include <string>
using namespace std;

enum BookStatus {
    IN,
    OUT,
    REPAIR,
    LOST
};

enum LoanStatus {
    NORMAL,
    OVERDUE
};

const array<string, 2> loanStatusStrings = {
    "Normal",
    "Overdue"
};

const array<string, 4> bookStatusStrings = {
    "In",
    "Out",
    "Repair",
    "Lost"
};

// Function declarations
string loanStatusToString(LoanStatus status);
string bookStatusToString(BookStatus status);

#endif
