// CSCE 1040.001
// Kai (Sam) Gu
// Homework 3

#include "Loans.h"
#include <iostream>
#include <ctime>
#include "Books.h"
#include "Patrons.h"

using namespace std;

// Some functionalities implemented in main.cpp


// Prompt the user for a bookID and patronID
// Use findBook(bookID) to verify the Book is available
// If findBook(bookID) returns -1, exit (book not found or already checked out)
// Use findPatron(patronID), then verify the Patron can check out books
// If findPatron(patronID) returns -1, exit (patron not found)
// Check if the Patron has fewer than 6 books checked out
// If the Patron has 6 or more books, exit (cannot check out more books)
// Create a new Loan object with the provided Book ID, Patron ID, and set the Due Date using <ctime> (std::time_t)
// Set the currentStatus of the Loan to NORMAL
// Add the Loan object to the Loans collection
// Update the Book's status to OUT
// Increment the Patron's current number of books out using the mutator function
void Loans::addLoan(const Loan& loanRef) {
    LoanList.push_back(loanRef);

}

// Prompt the user for Loan ID
// Use findLoan() to get the index of the Loan with the user-specified ID
// For the first parameter of editLoan(), insert the memory reference of the Loan object using the Loan index.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findLoan() does not return -1 (i.e. loan is in the loanList vector)
// If findLoan() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Loan object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Loans::editLoan(const Loan& loanRef, char choice, int changedParam) {
    int index = findLoan(loanRef.getID());
    if (index != -1) {
        if (choice == 'f') {
            LoanList[index].setFineRate(changedParam);
        } else {
            cout << "Invalid choice." << endl;
        }
    }
}

// Prompt the user for Loan ID
// Use findLoan() to get the index of the Loan with the user-specified ID
// For the first parameter of editLoan(), insert the memory reference of the Loan object using the Loan index.
// Prompt the user for a char that represents the field/attribute to be changed and a string/int to replace that field to be changed (represented in param).
// Check to make sure findLoan() does not return -1 (i.e. loan is in the loanList vector)
// If findLoan() does not return -1, call the mutator for the field identified in the char parameter to replace the attribute with the new user-prompted string or int. This function is called on the Loan object referenced in the params.
// Ensure type safety by comparing the type of changedParam to type of source instance variable. Only proceed if type is the same.
void Loans::editLoan(const Loan& loanRef, char choice, bool changedParam) {
    int index = findLoan(loanRef.getID());
    if (index != -1) {
        if (choice == 'r') {
            LoanList[index].setCanRecheck(changedParam);
        } else {
            cout << "Invalid choice." << endl;
        }
    }
}

// Prompt the user for a Loan ID
// Use findLoan(loanID) to get the index of the Loan with the specified Loan ID
// If findLoan() returns -1, exit (print “loan not found”)
// Retrieve the Loan object from the Loans collection using the index
// Use findBook(loan.bookID) to get the index of the associated Book
// Set the Book's status to AVAILABLE using the mutator function
// Use findPatron(loan.patronID) to get the index of the associated Patron
// Decrement the Patron's current number of books out using the mutator function
// Check if the Loan's currentStatus is OVERDUE
// If OVERDUE, calculate the fine using calculateFine(loanIndex), then,
// 	Add the calculated fine to the Patron's fine balance using the mutator function
// Delete Loan from overdueLoans
// Delete the Loan from the Loans collection using the index.
void Loans::deleteLoan(int id) {
    int index = findLoan(id);
    if (index != -1) {
        LoanList.erase(LoanList.begin() + index);
        cout << "Loan deleted successfully." << endl;
    } else {
        cout << "Loan not found." << endl;
    }
}

// Prompt user for ID
// Iterate through Loan collection using for-loop
// Check for ID that matches the user’s given ID
// Return index of Loan in the loanList vector with the the matching ID
int Loans::findLoan(int id) const {
    for (size_t i = 0; i < LoanList.size(); ++i) {
        if (LoanList[i].getID() == id) {
            return i;
        }
    }
    return -1;
}

// Display all current loans by calling printLoans().
// Verify if the provided index is valid (not equal to -1).
// If valid: Return the loan located at LoanList[index].
// Else: Throw a runtime error with the message "Loan not found."
Loan& Loans::getLoan(int index) {
    printLoans();
    if (index != -1) {
        return LoanList[index];
    } else {
        __throw_runtime_error("Loan not found.");
    }
}


// Go through the loanList vector and print out all elements of the Loans collection.
void Loans::printLoans() const {
    for (const auto& loan : LoanList) {
        cout << "Loan ID: " << loan.getID()
                  << ", Patron ID: " << loan.getPatronID()
                  << ", Book ID: " << loan.getBookID()
                  << ", Status: " << loan.getStatus()
                  << ", Due Date: " << loan.printDueDateAndTime() << endl;
    }
}

// Call aggregateOverdueLoans() to get a collection of overdue Loans.
// For each Loan in the overdueLoans collection:
// Print the Loan details (Loan ID, Book ID, Patron ID, Due Date, and Fine).
void Loans::listAllOverdueLoans() {
    aggregateOverdueLoans();
    if (overdueLoans.empty()) {
        cout << "No overdue loans." << endl;
        return;
    }
    for (const auto& loan : overdueLoans) {
        cout << "Overdue Loan ID: " << loan.getID()
                  << ", Patron ID: " << loan.getPatronID()
                  << ", Book ID: " << loan.getBookID()
                  << ", Due Date: " << loan.printDueDateAndTime() << endl;
    }
}

// Iterate through the Loans collection using a for-loop.
// For each Loan, check its currentStatus.
// If the currentStatus is OVERDUE, add the Loan to the overdueLoans collection.
void Loans::aggregateOverdueLoans() {
    overdueLoans.clear();
    time_t now = time(nullptr);
    for (const auto& loan : LoanList) {
        if (loan.getDueDateAndTime() < now) {
            overdueLoans.push_back(loan);
        }
    }
}

// Find the index of the loan using findLoan(id).
// Check if the loan exists (index is not -1).
// If the loan exists: Retrieve the loan from LoanList using the found index.
// Get the current time and store it in now.
// Determine if the loan is overdue by comparing dueDateAndTime with now:
// If overdue: Calculate daysOverdue by finding the difference between now and dueDateAndTime, then dividing by the number of seconds in a day.
// Compute the fine by multiplying daysOverdue with fineRate.
// Display a message indicating the loan ID, days overdue, and the fine amount.
// Else: Display a message stating that the loan is not overdue.
// Else: Display a message saying "Loan not found."
void Loans::calculateLoans(int id) {
    int index = findLoan(id);
    if (index != -1) {
        Loan& loan = LoanList[index];
        time_t now = time(nullptr);
        if (loan.getDueDateAndTime() < now) {
            double daysOverdue = difftime(now, loan.getDueDateAndTime()) / (60 * 60 * 24);
            double fine = daysOverdue * loan.getFineRate();
            cout << "Loan ID: " << loan.getID()
                      << " is overdue by " << daysOverdue << " days."
                      << " Fine: $" << fine << endl;
        } else {
            cout << "Loan ID: " << loan.getID() << " is not overdue." << endl;
        }
    } else {
        cout << "Loan not found." << endl;
    }
}

// Prompt the user for a Loan Index
// Use findLoan() to get the index of the Loan in the collection
// Make sure findLoan() does not return -1
// Check if the Loan at the given index has a book that has not been held for over 10 days without renewal. If it has, make the instance variable currentStatus Overdue.
// Also check if the book can be renewed by looking at the instance variable canRecheck.
void Loans::updateLoanStatus(int id) {
    int index = findLoan(id);
    if (index != -1) {
        Loan& loan = LoanList[index];
        time_t now = time(nullptr);
        if (loan.getDueDateAndTime() < now) {
            loan.setStatus(LoanStatus::OVERDUE);
            cout << "Loan status updated to OVERDUE." << endl;
        } else {
            loan.setStatus(LoanStatus::NORMAL);
            cout << "Loan status is NORMAL." << endl;
        }
    } else {
        cout << "Loan not found." << endl;
    }
}

// From loanRef, get the bookID and PatronID
// Use findBook(bookID) to get the associated Book
// If findBook(bookID) doesn’t return -1:
// Set the Book's status to LOST
// Use findPatron(patronID) to get the associated Patron
// If findPatron(patronID) doesn’t return -1:
// 	Add Book.cost to Patron’s fineBalance
// Remove the loan from the loan collection and overdue collection if applicable.
void Loans::reportLost(const Loan& loanRef, Books& books, Patrons& patrons) {
    int bookID = loanRef.getBookID();
    int patronID = loanRef.getPatronID();
    cout << "Loan ID: " << loanRef.getID() << endl;
    cout << "Book ID: " << bookID << endl;
    cout << "Patron ID: " << patronID << endl;

    int bookIndex = books.findBook(bookID);
    Book& book = books.getBook(bookIndex);
    book.setStatus(BookStatus::LOST);
    cout << "Book with ID " << bookID << " reported as lost." << endl;

    int patronIndex = patrons.findPatron(patronID);
    Patron& patron = patrons.getPatron(patronIndex);
    patron.addFine(book.getCost());
    cout << "Patron " << patron.getName() << " with ID " << patronID << " paid fine of $" << book.getCost() << "." << endl;
}

// Initialize a variable maxID to 0.
// Loop through each loan in LoanList:
// If the loan's ID is greater than maxID:
// Update maxID with this loan's ID.
// After the loop, return maxID + 1 as the new unique Loan ID.
int Loans::generateLoanID() const {
    int maxID = 0;
    for (const auto& loan : LoanList) {
        if (loan.getID() > maxID) {
            maxID = loan.getID();
        }
    }
    return maxID + 1;
}
